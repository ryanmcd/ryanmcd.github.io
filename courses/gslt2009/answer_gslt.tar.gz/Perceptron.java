import java.io.*;

public class Perceptron {
  public static void main(String[] args) throws IOException {

    DataReader reader = new DataReader();
    reader.init(args);

    Instance[] train_data = reader.getInstances(args[0]);
    Instance[] test_data = reader.getInstances(args[1]);

    PerceptronModel model = learn(train_data, 5);

    System.out.println("\n\n======================================================");
    System.out.println("Final Training Accuracy: " + model.accuracy(train_data));
    System.out.println("Final Testing Accuracy: " + model.accuracy(test_data));
    System.out.println("======================================================");

    model.setToAvgWeights();
    System.out.println("\n\n======================================================");
    System.out.println("Final Training Accuracy: " + model.accuracy(train_data));
    System.out.println("Final Testing Accuracy: " + model.accuracy(test_data));
    System.out.println("======================================================");
  }

  public static PerceptronModel learn(Instance[] train_data, int num_iters) {
    PerceptronModel model = new PerceptronModel();

    for(int i = 0; i < num_iters; i++) {
      for(int n = 0; n < train_data.length; n++) {
        Instance inst = train_data[n];
        int prediction = model.predict(inst);
        if(prediction != inst.real_label) {
          double[] features_corr = inst.getFeatures(inst.real_label);
          double[] features_wrong = inst.getFeatures(prediction);
          double[] updates = new double[features_corr.length];
          for(int j = 0; j < updates.length; j++) {
            updates[j] = features_corr[j] - features_wrong[j];
          }
          model.update(updates);
        }
	else {
	    double[] updates = new double[inst.getFeatures(inst.real_label).length];
	    model.update(updates);
	}
      }

      System.out.println("\n======================================================");
      System.out.println("Iteration " + (i+1) + ", Training Accuracy: " + model.accuracy(train_data));
      System.out.println("======================================================");
    }

    return model;
  }

}
