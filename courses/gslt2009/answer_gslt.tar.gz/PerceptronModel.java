public class PerceptronModel {
  public static DataReader reader;
  double[] weights;
  double[] avg_weights;
  int num_updates = 0;

  public PerceptronModel() {
    this.weights = new double[reader.num_features * reader.num_labels];
    this.avg_weights = new double[reader.num_features * reader.num_labels];
  }

  public int predict(Instance inst) {
    int best_label = 0;
    double best_score = Double.NEGATIVE_INFINITY;
    for(int l = 0; l < reader.num_labels; l++) {
      double score = inst.getScore(weights,l);
      if(score > best_score) { best_label = l; best_score = score; }
    }
    return best_label;
  }

  public double accuracy(Instance[] instances) {
    int correct = 0;
    int total = 0;
    for(int i = 0; i < instances.length; i++) {
      int predicted_label = predict(instances[i]);
      if(predicted_label == instances[i].real_label)
        correct++;
      total++;
    }
    return (double)correct/total;
  }

  public void update(double[] updates) {
    for(int i = 0; i < updates.length; i++) {
      weights[i] += updates[i];
    }
    for(int i = 0; i < weights.length; i++)
      avg_weights[i] += weights[i];
    num_updates++;
  }

  public void setToAvgWeights() {
    for(int i = 0; i < avg_weights.length; i++)
      avg_weights[i] = (double)avg_weights[i]/num_updates;
    weights = avg_weights;
  }

}
